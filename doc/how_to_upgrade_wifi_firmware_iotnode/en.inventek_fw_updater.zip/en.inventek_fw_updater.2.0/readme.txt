B-L475E-IOT01/B-L4S5I-IOT01 WiFi firmware update
------------------------------------------------

In order to update the Inventek ISM43362 WiFi module firmware on B-L475E-IOT01/B-L4S5I-IOT01
IoT Discovery Kit STM32 boards there are several steps:

NOTE: this update will fully erase the chip.

1. Install STM32CubeProgrammer (>=2.8.0) so that STM32_Programmer_CLI.exe path
   is "C:\Program Files\STMicroelectronics\STM32Cube\STM32CubeProgrammer\bin\STM32_Programmer_CLI.exe"
   (default install directory).
   Get STM32CubeProgrammer from https://www.st.com/en/development-tools/stm32cubeprog.html

2. Connect the STM32 IoT Discovery Kit board with USB to your PC.
   Check there is no other STM32 board connected to the PC other than the Discovery Kit board.
   Take note of the COM port number for the board (see Windows Device Manager in "Ports (COM & LPT)" category)
   Check that no serial terminal application has the STM32 board COM port open.

3. Update the ST-LINK firmware on the Discovery Kit STM32 board with STM32CubeProgrammer
    3.1 Start STM32CubeProgrammer GUI application.
    3.2 Check that "STLINK" connection method is select on top right side.
    3.2 In the 'ST-LINK configuration' pane (on right side), select 'Firmware update'
    3.3 Click on "Open in Update mode"
    3.4 If the installed STLINK firmware is ancient, click on "Upgrade"
    3.4 At the end of the procedure, close the Firmware update window and exit from STM32CubeProgrammer GUI

4. Go to https://www.inventeksys.com/iwin/firmware/ and download
   "STM32L4 Discovery kit IoT node (B-L475E-IOT01A) ISM43362-M3G-L44-SPI-C3.5.2.7.STM SPI Firmware".
   Unzip the .zip file. Rename the *.bin.rename file to *.bin.

5. Copy the ISM43362_M3G_L44_SPI_C3.5.2.7.STM.bin you just downloaded to \bin directory

6. From the \bin directory, run update_Wifi.bat.
   Enter the COM port for the STM32 board.
   The batch file will go through 3 steps:
    a.  Update the Discovery Kit firmware to InventekBootloaderPassthrough.bin using the STM32CubeProgrammer command line interface.
    b.  Use STM32Programmer_CLI in USB UART mode to erase the current Inventek WiFi firmware
    c.  Program the WiFi chip with ISM43362_M3G_L44_SPI_C3.5.2.7.STM.bin

After the WiFi update is successful you can erase the InventekBootloaderPassthrough.bin
firmware on the STM32 Discovery Kit board.

